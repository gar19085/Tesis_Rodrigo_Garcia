UNIVERSIDAD DEL VALLE DE GUATEMALA
ELECTRONICA DIGITAL 3
GABRIELA ALFARO, 19185
RODRIGO GARCIA, 19085
FECHA: 28/11/2021
PROYECTO FINAL
INSTRUCCIONES DE FUNCIONAMIENTO

EL ARCHIVO .ZIP
CONTIENE LOS SIGUIENTES ARCHIVOS:
-Historiador.c
-UTR1.c
-UTR2.c 
-Iot_Proyecto.ino 
-ReadMe.txt

Antes de compilar desde la terminal asegurarse de que se encuentra en la dirección en donde guardo los archivos.

Para que funcionen correctamente los programas en las raspberry es necesario compilar los programas de la siguiente manera:

gcc UTR1.c -o nombre_que_desea.exe -lpthread -lwiringPI

Para el historiador es necesario compilarlo de la siguiente manera:
gcc Historiador.c -o nombre_que_desea.exe -lpthread

Para el archivo del Arduino IoT es necesario descargar la apliecación LightBlue en su teléfono y activat el bluetooth así la aplicación reconoce el Arduino
Para compilarlo es necesario utilizar el Arduino IDE y conectar el Arduino a la computadora para subir el programa.


Luego al momento de que inicie las UTR, tiene que iniciar el programa del historiador rapidamente 
así este establece la conexión udp entre UTR y servidor para que los UTR no den error al momento de 
enviar información

Para el funcionamiento del ADC del potenciometro debe seguir las siguientes instrucciones de conexión del integrado.
Para conectar el integrado MCP3002 se deben seguir las siguientes instrucciones:
Nota 1: La Raspberry Pi tiene dos canales SPI.
Nota 2: El chip MCP3002 tiene 2 canales ADC.
Cuidado con los voltajes de entrada para el MCP3002. Deben estar entre 0 y VDD.
Se sugiere usar VDD = 3.3 V de la Raspberry Pi.
Recuerde conectar VSS del MCP3002 a la tierra de la RPi.

Los pines del Arduino son: A1 y A2
El A1 va conectado al GPIO 12 de la RPi 
El A2 al LED que enciende

En las UTR los pines que se utilizan son:
GPIO 5, 12, 13, 17, 19, 20, 21 y 26

En los GPIO 5 y 17 se conectan los PUSH BUTTONS como pull ups
En los GPIO 19, 26 se conectan los switches
En el GPIO 12 se conecta la entrada del Arduino IoT 
En los GPIO 20 y 21 van los LEDS
En el GPIO 13 se conecta la bocina

Utilizar los V3.3 de las RPi para alimentar los componentes